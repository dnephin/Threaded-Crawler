"""
 Data Transfer objects.
"""

import re
from datetime import date, tzinfo, timedelta

class HtmlDocument(object):
	"""
	A data transfer object that holds all the details about an HtmlDocument.
	"""

	def __init__(self, id=None, url=None, content=None, category=None, region=None):
		"""
		Instantiate a new object.

		@param id: the database row id of the object
		@type  id: int
		@param url: the original url of this document
		@type  url: string
		@param content: the contents of the document
		@type  content: unicode
		@param region: city or region data about this document
		@type  region: string
		@param category: the category this document falls into
		@type  category: string
		"""
		self.id = id
		self.url = url
		self.content = content
		self.region = region
		self.category = category


	def __str__(self):
		return "HtmlDocument[%s, %s]" % (self.id, self.url)



class Posting(object):
	"""
	An object representing a job posting.
	"""

	@staticmethod
	def from_dict(d):
		"""
		Build a Posting object from an arbitrary dictionary object.
		Any keys in the dict that are not fields in Posting are ignored.
		"""
		p = Posting()
		for k,v in d.iteritems():
			if k not in p.__dict__:
				continue
			p.__dict__[k] = v
		return p


	def __init__(self, id=None, domain=None, url=None, category=None, title=None,
			date=date.today(), location=None, city=None, summary=None, company=None, 
			salary=None, wage=None, type=None, email=None, phone=None,
			level=None, industry=None, requirements=None, recruiter=False, body=""):
		self.id = id
		self.domain = domain
		self.url = url
		self.category = category
		self.title = title or "untitled"
		self.date = date
		self.location = location
		self.city = city
		self.summary = summary
		self.company = company
		self.salary = salary
		self.wage = wage
		self.type = type
		self.email = email
		self.phone = phone
		self.level = level
		self.industry = industry
		self.requirements = requirements
		self.recruiter = recruiter
		self.body = body


	def __iter__(self):
		return self.__dict__.__iter__()

	def items(self):
		return self.__dict__.items()



class TZinfo(tzinfo):
	"""
	Timezone info class to identify the offset from utc.
	"""

	def __init__(self, offset=0):
		self.offset = 0

	def utcoffset(self, dt):
		return 60 * self.offset;

	def tzname(self, dt):
		if self.offset == -5:
			return 'EST'
		return None
	
	def dst(self, dt):
		return timedelta(0)

