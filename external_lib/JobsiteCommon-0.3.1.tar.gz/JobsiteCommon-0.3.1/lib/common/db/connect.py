"""
Connection handling for database connections.
"""

import psycopg2
import psycopg2.extensions
from psycopg2.pool import ThreadedConnectionPool

from common.pattern import Singleton

# Set response to UNICODE globally
psycopg2.extensions.register_type(psycopg2.extensions.UNICODE)

class ConnectionUtil(object):
	"""
	Manage database connections.  This class handles a pool of connections, 
	and hands them out as needed.
	"""

	__pool = {}
	" @cvar: map of database name to connection pool "

	def __init__(self):
		pass

	@staticmethod
	def configure(db_name, config):
		min_conn = config.get('min_conn', 1)
		max_conn = config.get('max_conn', 10)
		if 'min_conn' in config:
			del config['min_conn']
		if 'max_conn' in config:
			del config['max_conn']
		ConnectionUtil.__pool[db_name] = ThreadedConnectionPool(
				min_conn, max_conn, **config)


	@staticmethod
	def get_conn_for_db(db_name):
		"""
		Retrieve a connection from the pool for a given database.

		@param db_name: database name
		@type  db_name: string
		"""
		if db_name not in ConnectionUtil.__pool:
			raise ValueError("Connection pool for %s is null, you must "
					"configure it first." % db_name)
		return ConnectionUtil.__pool[db_name].getconn()


	@staticmethod
	def release_conn_for_db(db_name, conn):
		"""
		Release a connection to the pool for a given database.

		@param db_name: database name
		@type  db_name: string
		"""
		if db_name not in ConnectionUtil.__pool:
			raise ValueError("Connection pool for %s is null, you must "
					"configure it first." % db_name)
		return ConnectionUtil.__pool[db_name].putconn(conn)


	@staticmethod
	def close():
		"""
		 Close all the connections.
		"""
		for pool in ConnectionUtil.__pool.values():
			pool.closeall()

