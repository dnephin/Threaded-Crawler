"""
 Solr indexing.
"""

from common.pattern import Singleton
import solr
import logging
import threading

log = logging.getLogger("SolrIndexer")


class SolrIndexer(object):
	"""
	This class is responsible for sending postings to solr for indexing.

	Configuration values:
		conn_url - solr connection url
		exclude_details - list of details to exclude from the index
	"""
	__metaclass__ = Singleton

	def __init__(self):
		self.config()
		self.queued = 0
		self.lock = threading.Lock()


	def config(self, conf={}):
		conn_url = conf.get('conn_url', 'http://localhost:8080/solr')
		self.conn = solr.SolrConnection(conn_url)
		self.exclude_details = set(conf.get('exclude_details', ''))
		self.batch_commit_size = conf.get('batch_commit_size', 100)

	
	def add(self, posting):
		"""
		Add a Posting to the index.
		"""
		self.lock.acquire()
		d = posting.__dict__
		for detail in self.exclude_details:
			d.pop(detail)
		self.conn.add(**d)
		self.queued += 1

		if self.queued >= self.batch_commit_size:
			self.commit()
			self.queued = 0
		self.lock.release()

	def commit(self):
		self.conn.commit(False, False)

	def shutdown(self):
		self.commit()
		self.conn.close()
