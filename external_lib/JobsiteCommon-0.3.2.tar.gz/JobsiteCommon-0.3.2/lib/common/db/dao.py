"""
 Data access objects for the Detail Parser.
"""

from common.db.connect import ConnectionUtil
from common.db.objects import HtmlDocument


class AbstractDAOObject(object):
	"""
	An abstract base class for DAO objects.
	"""

	def __init__(self):
		raise ValueError("Can not instantiate an abstract class [%s]." % self.__class__.__name__)

	def get_cursor(self):
		"""
		Get a fresh cursor from a connection in the pool.

		@return: a cursor to execute database commands.
		@rtype: cursor
		"""
		return ConnectionUtil.get_conn_for_db(self.DB_NAME).cursor()

	def release_cursor(self, cursor):
		"""
		Close the cursor and return a connection to the pool.

		@param cursor: the connection to be released to the pool.
		@type  cursor: psycopg2.cursor
		"""
		conn = cursor.connection
		conn.commit()
		cursor.close()
		ConnectionUtil.release_conn_for_db(self.DB_NAME, conn)


class DocumentDAO(AbstractDAOObject):
	"""
	Loads HtmlDocuments with meta data.
	"""

	def __init__(self, db_name=None):
		if db_name:
			self.DB_NAME = db_name

	DB_NAME = 'raw'
	" @cvar: the name of the database which contains the HtmlDocument table. "

	__insert_prefix = "INSERT into htmldocument(url, content, category, region) VALUES"
	" @cvar: string used to construct the insert query "
	__insert_values =   "(%s, %s, %s, %s)";
	" @cvar: string used to construct the insert query "

	def _build_document(self, row):
		"""
		Build an HtmlDocument from a cursor row.

		@param row: a cursor row
		@type  row: tuple
		@return: the HtmlDocument
		@rtype: HtmlDocument
		"""
		return HtmlDocument(row[0], row[1], unicode(row[2]), row[3], row[4])

	def _unbuild_document(self, doc):
		"""
		Create a string representation of an HtmlDocument that can be used to 
		insert it into the database.

		@param doc: the document to insert
		@type  doc: L{dparser.data.objects.HtmlDocument}
		@return: a tuple of string representing the document
		@rtype: tuple
		"""
		return (doc.url, doc.content, doc.category, doc.region)


	def get_next_batch(self, num):
		"""
		Retrieve up to 'num' HtmlDocuments, and return them as a list.

		@param num: the maximum number of documents to fetch.
		@type  num: int
		@return: the list of documents or None if no rows are returned
		"""
		if num < 1:
			return None

		cursor = self.get_cursor()
		# See SQL files for details about this proc
		cursor.callproc("get_next_batch_documents", (num,));
		docs = map(self._build_document, cursor.fetchall())
		
		self.release_cursor(cursor)
		return docs


	def save(self, doc_list):
		"""
		Save an HtmlDocument.

		@param doc_list: a list of  HtmlDocument to save to the database.
		@type  doc_list: list (of HtmlDocument)
		"""
		# TODO: error conditions
		# TODO: create a stored proc for this
		if not doc_list:
			return

		values = tuple()
		rows = []
		for doc in doc_list:
			values += self._unbuild_document(doc)
			rows.append(self.__insert_values)

		cursor = self.get_cursor()
		query = self.__insert_prefix + ",".join(rows)
		cursor.execute(query, values)
		self.release_cursor(cursor)


	def get_by_id(self, id):
		"""
		Retrieve an HtmlDocument by its id.

		@param id: the id of the document
		@type  id: int
		"""
		if not id:
			return

		cursor = self.get_cursor()
		cursor.execute("select * from htmldocument where id=%s", (id,))
		# TODO: handle error of missing document
		doc = self._build_document(cursor.fetchone())
		self.release_cursor(cursor)
		return doc



class PostingDAO(AbstractDAOObject):
	"""
	DAO for Posting objects.
	"""

	DB_NAME = 'jobs'
	" @cvar: database name for Posting table. "


	def __init__(self, db_name=None):
		if db_name:
			self.DB_NAME = db_name

	def _unbuild_posting(self, posting):
		return (
			posting.domain,
			posting.url,
			posting.category,
			posting.title,
			posting.date,
			posting.location,
			posting.city,
			posting.summary,
			posting.company,
			posting.salary,
			posting.wage,
			posting.type,
			posting.email,
			posting.phone,
			posting.level,
			posting.industry,
			posting.requirements,
			posting.recruiter,
			posting.body
		)


	def save(self, posting):
		"""
		Save the posting.
		"""
		values = self._unbuild_posting(posting)
		cursor = self.get_cursor()
		cursor.execute("insert into posting values(DEFAULT, %s)" %
				(','.join(['%s' for x in range(len(values)) ]) ), values)
		self.release_cursor(cursor)



class ConfigurationDAO(AbstractDAOObject):
	"""
	Loads ProcessorConfigurations.
	"""

	def __init__(self):
		pass

	def get_all(self):
		# TODO:
		return []
