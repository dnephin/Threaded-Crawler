"""
 Common collections.
"""

from bisect import bisect_left

class SortedList(object):
	"""
	A list of items that remains sorted by the key function.  
	
	Modified version of the SortedCollection recipe from:
	http://code.activestate.com/recipes/577197-sortedcollection/
	"""

	def __init__(self, iterable=[], key=lambda x: x, reverse=False):
		self._key = key
		self._items = sorted(iterable, key=self._key, reverse=reverse)
		self._keys = map(self._key, self._items)
		self.reverse = reverse

	def insert(self, item):
		" Insert a new item.  If equal keys are found, add to the left "
		key = self._key(item)
		if self.reverse:
			i = self._reverse_bisect(self._keys, key)
		else:
			i = bisect_left(self._keys, key)
		self._keys.insert(i, key)
		self._items.insert(i, item)


	@staticmethod
	def _reverse_bisect(a, x, lo=0, hi=None):
		"""
		Return the index where to insert item x in list a, assuming a is sorted.
	
		The return value i is such that all e in a[:i] have e >= x, and all e in
		a[i:] have e < x.  So if x already appears in the list, a.insert(x) will
		insert just before the leftmost x already there.
	
		Optional args lo (default 0) and hi (default len(a)) bound the
		slice of a to be searched.

		Modified from bisect.bisect_left
		"""
		if lo < 0:
			raise ValueError('lo must be non-negative')
		if hi is None:
			hi = len(a)
		while lo < hi:
			mid = (lo+hi)//2
			if a[mid] > x: lo = mid+1
			else: hi = mid
		return lo


	def extend(self, iterable):
		"""
		Extend the SortedList with all items in iterable. The sort is preserved as
		items are inserted.
		"""
		for item in iterable:
			self.insert(item)

	def append(self, x):
		raise AttributeError("Can not append to a SortedList.")

	def reverse(self):
		raise AttributeError("Can not reverse a SortedList.")

	def sort(self):
		pass

	def __getitem__(self, i):
		return self._items[i]

	def __iter__(self):
		return iter(self._items)

	def __reversed__(self):
		return reversed(self._items)

	def __len__(self):
		return len(self._items)

	def __repr__(self):
		return '%s(%r, key=%s)' % (
			self.__class__.__name__,
			self._items,
			getattr(self._key, '__name__', repr(self._key))
		)	
