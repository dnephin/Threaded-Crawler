"""
 Static constants for detail parser.
"""

ID			= 'id'
DOMAIN		= 'domain'
CITY 		= 'city'
TITLE 		= 'title'
SUMMARY		= 'summary'
CATEGORY 	= 'category'
LOCATION	= 'location'
COMPANY		= 'company'
SALARY		= 'salary'
WAGE		= 'wage'
TYPE		= 'type'
EMAIL		= 'email'
PHONE		= 'phone'
LEVEL		= 'level'
INDUSTRY	= 'industry'
REQUIREMENTS	= 'requirements'
RECRUITER	= 'recruiter'
BODY		= 'body'
URL			= 'url'
