"""
 Common design patterns.
"""

import threading 

class Singleton(type):
	"""
	A thread-safe singleton class type.
	"""
	def __init__(cls, name, bases, dict):
		" Initialize the class type with an instance and a lock. "
		super(Singleton, cls).__init__(name, bases, dict)
		cls.instance = None
		cls.lock = threading.Lock()
 
	def __call__(cls, *args, **kw):
		"""
		Called when creating a new object of this type.
		"""
		cls.lock.acquire()
		if cls.instance is None:
			cls.instance = super(Singleton, cls).__call__(*args, **kw)

 		cls.lock.release()
		return cls.instance

