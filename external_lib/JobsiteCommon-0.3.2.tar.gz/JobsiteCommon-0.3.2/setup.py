from setuptools import setup, find_packages

setup(
	name = 'JobsiteCommon',
	version = '0.3.2',
	packages = find_packages('lib'),
	package_dir = {
		'common': 'lib/common',
	},
	scripts = ['cmd'],
	author = 'Perzoot',
	author_email = 'daniel@perzoot.com',
	url = 'common.git'

)
